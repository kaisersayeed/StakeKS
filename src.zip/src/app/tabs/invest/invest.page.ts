import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { DataService } from '../../core/services/data.service';
import { PortfolioSummary, StockDetail } from '../../core/models/stock.model';

@Component({
    selector: 'app-invest',
    templateUrl: './invest.page.html',
    styleUrls: ['./invest.page.scss'],
})
export class InvestPage implements OnInit {
    portfolio$!: Observable<PortfolioSummary>;
    trending$!: Observable<StockDetail[]>;

    constructor(
        private dataService: DataService,
        private router: Router
    ) { }

    ngOnInit() {
        this.portfolio$ = this.dataService.getHoldings();
        this.trending$ = this.dataService.getTrendingStocks();
    }

    onStockClick(symbol: string) {
        this.router.navigate(['/order', symbol]);
    }
}