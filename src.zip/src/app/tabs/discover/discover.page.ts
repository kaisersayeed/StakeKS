import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { DataService } from '../../core/services/data.service';
import { StockDetail } from '../../core/models/stock.model';

@Component({
    selector: 'app-discover',
    templateUrl: './discover.page.html',
    styleUrls: ['./discover.page.scss'],
})
export class DiscoverPage implements OnInit {
    searchControl = new FormControl('');
    searchResults$!: Observable<StockDetail[]>;
    topVolume$!: Observable<StockDetail[]>;

    constructor(private dataService: DataService) { }

    ngOnInit() {
        this.topVolume$ = this.dataService.getTrendingStocks();

        this.searchResults$ = this.searchControl.valueChanges.pipe(
            debounceTime(300),
            distinctUntilChanged(),
            switchMap(query => {
                if (!query || query.length < 2) {
                    return of([]);
                }
                return this.dataService.searchStocks(query);
            })
        );
    }

    onStockClick(symbol: string) {
        console.log('Stock clicked:', symbol);
        // TODO: Navigate to order page
    }
}