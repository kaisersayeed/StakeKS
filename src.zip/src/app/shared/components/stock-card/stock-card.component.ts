import { Component, Input, Output, EventEmitter } from '@angular/core';
import { StockDetail, HoldingPosition } from '../../../core/models/stock.model';

@Component({
    selector: 'app-stock-card',
    templateUrl: './stock-card.component.html',
    styleUrls: ['./stock-card.component.scss']
})
export class StockCardComponent {
    @Input() stock!: StockDetail | HoldingPosition;
    @Input() showType: boolean = true;
    @Output() cardClick = new EventEmitter<string>();

    onClick(): void {
        this.cardClick.emit(this.stock.symbol);
    }

    isStockDetail(stock: StockDetail | HoldingPosition): stock is StockDetail {
        return 'fullName' in stock;
    }

    isHolding(stock: StockDetail | HoldingPosition): stock is HoldingPosition {
        return 'quantity' in stock;
    }

    formatNumber(num: number | null): string {
        if (num === null) return 'N/A';
        if (num >= 1e12) return (num / 1e12).toFixed(2) + 'T';
        if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
        if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
        return num.toFixed(2);
    }
}