import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { StockCardComponent } from './components/stock-card/stock-card.component';

@NgModule({
    declarations: [
        StockCardComponent
    ],
    imports: [
        CommonModule,
        IonicModule
    ],
    exports: [
        StockCardComponent
    ]
})
export class SharedModule { }