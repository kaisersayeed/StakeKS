import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, combineLatest, of } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { StockDetail, HoldingPosition, PortfolioSummary } from '../models/stock.model';

interface PricingData {
    symbol: string;
    open: number;
    close: number;
    ask: number;
    high: number;
    low: number;
}

interface DetailData {
    symbol: string;
    fullName: string;
    logo: string;
    type: 'stock' | 'etf' | 'otc';
    volume: number | null;
    marketCap: number | null;
}

@Injectable({
    providedIn: 'root'
})
export class DataService {
    private detailsCache$: Observable<DetailData[]>;
    private pricingCache$: Observable<PricingData[]>;

    // Mock holdings - symbols the user owns
    private mockHoldingsSymbols = ['AAPL', 'GOOGL', 'NVDA', 'TSLA', 'FIG'];

    constructor(private http: HttpClient) {
        // Load and cache data
        this.detailsCache$ = this.http.get<DetailData[]>('assets/data/details.json').pipe(
            shareReplay(1)
        );

        this.pricingCache$ = this.http.get<PricingData[]>('assets/data/pricing.json').pipe(
            shareReplay(1)
        );
    }

    // Get all stocks with enriched data
    getAllStocks(): Observable<StockDetail[]> {
        return combineLatest([this.detailsCache$, this.pricingCache$]).pipe(
            map(([details, pricing]) => {
                return details.map(detail => {
                    const price = pricing.find(p => p.symbol === detail.symbol);
                    if (!price) return null;

                    return this.enrichStockData(detail, price);
                }).filter(stock => stock !== null) as StockDetail[];
            }),
            shareReplay(1)
        );
    }

    // Get single stock by symbol
    getStock(symbol: string): Observable<StockDetail | null> {
        return combineLatest([this.detailsCache$, this.pricingCache$]).pipe(
            map(([details, pricing]) => {
                const detail = details.find(d => d.symbol === symbol);
                const price = pricing.find(p => p.symbol === symbol);

                if (!detail || !price) return null;
                return this.enrichStockData(detail, price);
            })
        );
    }

    // Get user's portfolio holdings - shows all stocks from data files
    getHoldings(): Observable<PortfolioSummary> {
        return combineLatest([this.detailsCache$, this.pricingCache$]).pipe(
            map(([details, pricing]) => {
                // Use all stocks from data files
                const positions: HoldingPosition[] = details.map(detail => {
                    const price = pricing.find(p => p.symbol === detail.symbol);

                    if (!price) return null;

                    // Generate mock position data
                    const quantity = Math.floor(Math.random() * 50) + 5;
                    const avgCost = price.close * (0.85 + Math.random() * 0.25);
                    const currentPrice = price.ask;
                    const totalCost = quantity * avgCost;
                    const currentValue = quantity * currentPrice;

                    return {
                        id: `holding-${detail.symbol}`,
                        symbol: detail.symbol,
                        quantity,
                        averageCost: avgCost,
                        totalCost,
                        currentPrice,
                        currentValue,
                        unrealizedGain: currentValue - totalCost,
                        unrealizedGainPercent: ((currentValue - totalCost) / totalCost) * 100,
                        lastUpdated: new Date().toISOString()
                    };
                }).filter(p => p !== null) as HoldingPosition[];

                const totalEquity = positions.reduce((sum, p) => sum + p.currentValue, 0);
                const totalCost = positions.reduce((sum, p) => sum + p.totalCost, 0);
                const totalGain = totalEquity - totalCost;

                return {
                    totalEquity,
                    totalCost,
                    totalGain,
                    totalGainPercent: (totalGain / totalCost) * 100,
                    positions
                };
            }),
            shareReplay(1)
        );
    }

    // Get trending stocks (top 3 by volume)
    getTrendingStocks(): Observable<StockDetail[]> {
        return this.getAllStocks().pipe(
            map(stocks => {
                return stocks
                    .filter(s => s.volume !== null)
                    .sort((a, b) => (b.volume || 0) - (a.volume || 0))
                    .slice(0, 3);
            })
        );
    }

    // Search stocks
    searchStocks(query: string): Observable<StockDetail[]> {
        if (!query.trim()) {
            return of([]);
        }

        return this.getAllStocks().pipe(
            map(stocks => {
                const lowerQuery = query.toLowerCase();
                return stocks.filter(stock =>
                    stock.symbol.toLowerCase().includes(lowerQuery) ||
                    stock.fullName.toLowerCase().includes(lowerQuery)
                );
            })
        );
    }

    private enrichStockData(detail: DetailData, price: PricingData): StockDetail {
        const change = price.ask - price.close;
        const changePercent = (change / price.close) * 100;

        return {
            id: `stock-${detail.symbol}`,
            symbol: detail.symbol,
            fullName: detail.fullName,
            logo: detail.logo,
            type: detail.type,
            currentPrice: price.ask,
            open: price.open,
            close: price.close,
            high: price.high,
            low: price.low,
            ask: price.ask,
            change,
            changePercent,
            volume: detail.volume,
            marketCap: detail.marketCap
        };
    }
}