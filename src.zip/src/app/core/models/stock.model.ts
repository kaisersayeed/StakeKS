export interface StockDetail {
    id: string;
    symbol: string;
    fullName: string;
    logo: string;
    type: 'stock' | 'etf' | 'otc';
    currentPrice: number;
    open: number;
    close: number;
    high: number;
    low: number;
    ask: number;
    change: number;
    changePercent: number;
    volume: number | null;
    marketCap: number | null;
}

export interface HoldingPosition {
    id: string;
    symbol: string;
    quantity: number;
    averageCost: number;
    totalCost: number;
    currentPrice: number;
    currentValue: number;
    unrealizedGain: number;
    unrealizedGainPercent: number;
    lastUpdated: string;
}

export interface PortfolioSummary {
    totalEquity: number;
    totalCost: number;
    totalGain: number;
    totalGainPercent: number;
    positions: HoldingPosition[];
}

export interface SearchResult {
    symbol: string;
    fullName: string;
    logo: string;
    type: string;
    currentPrice: number;
    changePercent: number;
}

export interface OrderRequest {
    symbol: string;
    orderType: 'market' | 'limit';
    side: 'buy' | 'sell';
    quantity: number;
    amount: number;
    limitPrice?: number;
}

export interface OrderResponse {
    orderId: string;
    status: 'pending' | 'filled' | 'rejected';
    symbol: string;
    quantity: number;
    executionPrice: number;
    totalValue: number;
    timestamp: string;
}