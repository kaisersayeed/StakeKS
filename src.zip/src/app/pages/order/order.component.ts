import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { DataService } from '../../core/services/data.service';
import { StockDetail } from '../../core/models/stock.model';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  symbol: string = '';
  stock$!: Observable<StockDetail | null>;
  amount: number = 61;
  shares: number = 500;

  // Swipe to buy
  isDragging = false;
  startX = 0;
  currentX = 0;
  sliderWidth = 0;
  isComplete = false;
  showNotification = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.symbol = this.route.snapshot.paramMap.get('symbol') || '';
    this.stock$ = this.dataService.getStock(this.symbol);

    this.stock$.subscribe(stock => {
      if (stock) {
        this.shares = this.calculateShares(this.amount, stock.currentPrice);
      }
    });
  }

  calculateShares(amount: number, price: number): number {
    return Math.floor((amount / price) * 100) / 100;
  }

  onTouchStart(event: TouchEvent) {
    this.isDragging = true;
    this.startX = event.touches[0].clientX;
    const slider = event.target as HTMLElement;
    const container = slider.parentElement;
    if (container) {
      this.sliderWidth = container.offsetWidth - slider.offsetWidth;
    }
  }

  onTouchMove(event: TouchEvent) {
    if (!this.isDragging) return;

    const touch = event.touches[0];
    const deltaX = touch.clientX - this.startX;
    this.currentX = Math.max(0, Math.min(deltaX, this.sliderWidth));

    const slider = event.target as HTMLElement;
    slider.style.transform = `translateX(${this.currentX}px)`;

    // Change opacity based on progress
    const progress = this.currentX / this.sliderWidth;
    const track = slider.parentElement;
    if (track) {
      track.style.setProperty('--progress', progress.toString());
    }
  }

  onTouchEnd(event: TouchEvent) {
    if (!this.isDragging) return;

    const slider = event.target as HTMLElement;
    const progress = this.currentX / this.sliderWidth;

    if (progress > 0.85) {
      // Complete the purchase
      this.completePurchase(slider);
    } else {
      // Reset slider
      slider.style.transform = 'translateX(0)';
      const track = slider.parentElement;
      if (track) {
        track.style.setProperty('--progress', '0');
      }
    }

    this.isDragging = false;
    this.currentX = 0;
  }

  completePurchase(slider: HTMLElement) {
    slider.style.transform = `translateX(${this.sliderWidth}px)`;
    const track = slider.parentElement;
    if (track) {
      track.style.setProperty('--progress', '1');
    }

    this.isComplete = true;

    // Show success notification
    setTimeout(() => {
      this.showNotification = true;

      // Hide notification and navigate back after 2 seconds
      setTimeout(() => {
        this.showNotification = false;
        this.router.navigate(['/tabs/invest']);
      }, 2000);
    }, 300);
  }

  goBack() {
    this.router.navigate(['/tabs/invest']);
  }
}
